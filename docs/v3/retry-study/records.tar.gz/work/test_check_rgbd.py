from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

import numpy as np

from check_rgbd import inspect_rgbd


def test_valid_depth_ratio():
    rgb = np.zeros((2, 2, 3), dtype=np.uint8)
    depth = np.array([
        [0.5, 1.0, 2.0, 2.9],
        [0.0, 3.0, np.nan, np.inf],
    ])

    path = Path("work/test_frame.npz")
    path.parent.mkdir(exist_ok=True)
    print("RGB 크기:", rgb.shape)
    print("입력 깊이:\n", depth)
    np.savez(path, rgb=rgb, depth=depth)

    output = StringIO()
    with redirect_stdout(output):
        inspect_rgbd(path)

    lines = output.getvalue().splitlines()
    assert "이미지 크기 (너비 x 높이): 4 x 2" in lines
    assert "유효 깊이 비율: 50.00%" in lines
    print(output.getvalue(), end="")


if __name__ == "__main__":
    test_valid_depth_ratio()
